{% extends 'usernavbar.html' %}
{% block main %}

<div class="pagetitle">
    <h1>Change Password</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
            <li class="breadcrumb-item active">Change Password</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<script>
    function checkpassword(){
    if(document.changepassword.newpassword.value!=document.changepassword.confirmpassword.value){
    alert('New Password and Confirm Password field does not Match');
    document.changepassword.confirmpassword.focus();
    return false;
    }
    return true;
    }
</script>

{% if error == "no" %}
<script>
    alert('Password updated successfully');
    window.location=('{% url 'signout' %}');
</script>
{% endif %}
{% if error == "yes" %}
<script>
    alert('Something went wrong , try again later');
</script>
{% endif %}

{% if error == "not" %}
<script>
    alert('Your current password is wrong');
</script>
{% endif %}

<section class="section profile">
    <div class="row">

        <div class="col-xl-15">

            <div class="card">
                <div class="card-body pt-5">
                    <!-- Bordered Tabs -->
                    <ul class="nav nav-tabs nav-tabs-bordered">

                        <li class="nav-item">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">
                                Change Password
                            </button>
                        </li>

                    </ul>
                    <div class="tab-content pt-10">

                        <div class="tab-pane fade show active profile-overview" id="profile-overview">
                            <form method="post" name="changepassword" onsubmit="return checkpassword()">
                                {% csrf_token %}

                                <div class="row mb-9">
                                    <label class="col-md-8 col-lg-9 col-form-label">Current Password</label>
                                    <div class="col-md-10 col-lg-11">
                                        <input type="password" name="oldpassword" class="form-control" placeholder="Current Password" required>
                                    </div>
                                </div>

                                <div class="row mb-9">
                                    <label class="col-md-8 col-lg-9 col-form-label">New Password</label>
                                    <div class="col-md-10 col-lg-11">
                                        <input type="password" name="newpassword" class="form-control" placeholder="New Password" required>
                                    </div>
                                </div>

                                <div class="row mb-9">
                                    <label class="col-md-8 col-lg-9 col-form-label">Confirm Password</label>
                                    <div class="col-md-10 col-lg-11">
                                        <input type="password" name="confirmpassword" class="form-control" placeholder="Confirm Password" required>
                                    </div>
                                </div>



                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form><!-- End Profile Edit Form -->

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


{% endblock %}